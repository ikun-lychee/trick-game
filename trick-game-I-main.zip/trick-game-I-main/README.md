# 关于该游戏


[https://code.xueersi.com/home/project/detail?lang=code&pid=36585269&version=offline&form=python&langType=python](https://code.xueersi.com/home/project/detail?lang=code&pid=36585269&version=offline&form=python&langType=python)
